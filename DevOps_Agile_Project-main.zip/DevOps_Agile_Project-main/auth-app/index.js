const express = require("express");
const path = require("path");
const bodyParser = require("body-parser");
const mysql = require("mysql2");
const bcrypt = require("bcryptjs");
const dotenv = require("dotenv");
const rateLimit = require("express-rate-limit");

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());

// Rate Limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
});
app.use(limiter);

// Serve static files (CSS, images, etc.) from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// Database connection
const db = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) {
    console.error("MySQL connection error:", err);
    process.exit(1);
  }
  console.log("MySQL Connected...");
});

// Route to serve the Sign-Up page when visiting the root URL
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'sign-up.html')); // Serve sign-up.html from the 'views' folder
});

app.get("/sign-up", (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'sign-up.html'));
});

// Sign-Up Route
app.post("/sign-up", async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    db.query(sql, [username, email, hashedPassword], (err, result) => {
      if (err) {
        console.error("Error signing up:", err);
        return res.status(500).send("Error signing up");
      }
      res.send("User registered successfully!");
    });
  } catch (error) {
    console.error("Error hashing password:", error);
    res.status(500).send("Server error");
  }
});

// Route to serve the Sign-In page
app.get("/sign-in", (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'sign-in.html')); // Serve sign-in.html
});

// Sign-In Route
app.post("/sign-in", async (req, res) => {
  const { username, password } = req.body;
  const sql = "SELECT * FROM users WHERE username = ? OR email = ?";
  db.query(sql, [username, username], async (err, results) => {
    if (err) {
      console.error("Server error:", err);
      return res.status(500).send("Server error");
    }
    if (results.length === 0) {
      // User not found, create a new account
      try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const insertSql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        db.query(insertSql, [username, username, hashedPassword], (insertErr, insertResult) => {
          if (insertErr) {
            console.error("Error creating account:", insertErr);
            return res.status(500).send("Error creating account");
          }
          res.send("User registered and signed in successfully!");
        });
      } catch (hashError) {
        console.error("Error hashing password:", hashError);
        res.status(500).send("Server error");
      }
    } else {
      // User found, check password
      const user = results[0];
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        res.status(401).send("Invalid credentials");
      } else {
        res.send("Sign-in successful!");
      }
    }
  });
});

app.get("/forgot-pass", (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'forgot-pass.html'));
});

// Forgot Password Route
app.post("/forgot-password", (req, res) => {
  const { email } = req.body;
  const sql = "SELECT * FROM users WHERE email = ?";
  db.query(sql, [email], (err, results) => {
    if (err) {
      console.error("Server error:", err);
      return res.status(500).send("Server error");
    }
    if (results.length === 0) return res.status(404).send("Email not found");

    res.send("Password reset link has been sent to your email.");
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
