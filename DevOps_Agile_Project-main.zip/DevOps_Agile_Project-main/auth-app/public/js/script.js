document.querySelector('.upcoming i').addEventListener('click', function() {
    var submenu = document.querySelector('.submenu');
    submenu.classList.toggle('show');
    submenu.classList.toggle('hidden');
});