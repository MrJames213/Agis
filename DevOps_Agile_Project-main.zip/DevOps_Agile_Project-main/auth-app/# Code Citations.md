# Code Citations

## License: unknown
https://github.com/Jawqpuizz/Fashop.io/tree/db7460797727f835199ad008b5bfa37945ada991/config/passport.js

```
createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
});

db.connect((err) => {
  if (err) {
    console.
```

