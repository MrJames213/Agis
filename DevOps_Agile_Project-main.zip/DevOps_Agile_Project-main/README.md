# DevOps_Agile_Project

This project is a simple authentication application built with Node.js, Express, and MySQL. It includes features for user sign-up, sign-in, and password reset.

## Setup Instructions

### Backend

1. Clone the repository:
   ```sh
   git clone <repository-url>
   ```

2. Navigate to the backend directory:
   ```sh
   cd DevOps_Agile_Project-main/backend
   ```

3. Install the dependencies:
   ```sh
   npm install
   ```

4. Create a `.env` file in the root directory and add your MySQL database credentials:
   ```
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=MitsuSQL5847
   DB_NAME=auth_db
   ```

5. Start the server:
   ```sh
   npm start
   ```

6. Open your browser and navigate to `http://localhost:3000` to access the backend API.

### Frontend

1. Navigate to the frontend directory:
   ```sh
   cd DevOps_Agile_Project-main/frontend
   ```

2. Install the dependencies:
   ```sh
   npm install
   ```

3. Start the development server:
   ```sh
   npm start
   ```

4. Open your browser and navigate to `http://localhost:3000` to access the frontend application.