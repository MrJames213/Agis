const express = require("express");
const path = require("path");
const bcrypt = require("bcryptjs");
const db = require("../config/db");

const router = express.Router();

// Route to serve the Sign-Up page
router.get("/sign-up", (req, res) => {
  res.sendFile(path.join(__dirname, '../views', 'sign-up.html'));
});

// Sign-Up Route
router.post("/sign-up", async (req, res) => {
  const { username, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const sql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    db.query(sql, [username, email, hashedPassword], (err, result) => {
      if (err) {
        console.error("Error signing up:", err);
        return res.status(500).send("Error signing up");
      }
      res.send("User registered successfully!");
    });
  } catch (error) {
    console.error("Error hashing password:", error);
    res.status(500).send("Server error");
  }
});

// Route to serve the Sign-In page
router.get("/sign-in", (req, res) => {
  res.sendFile(path.join(__dirname, '../views', 'sign-in.html'));
});

// Sign-In Route
router.post("/sign-in", async (req, res) => {
  const { username, password } = req.body;
  const sql = "SELECT * FROM users WHERE username = ? OR email = ?";
  db.query(sql, [username, username], async (err, results) => {
    if (err) {
      console.error("Server error:", err);
      return res.status(500).send("Server error");
    }
    if (results.length === 0) {
      // User not found, create a new account
      try {
        const hashedPassword = await bcrypt.hash(password, 10);
        const insertSql = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        db.query(insertSql, [username, username, hashedPassword], (insertErr, insertResult) => {
          if (insertErr) {
            console.error("Error creating account:", insertErr);
            return res.status(500).send("Error creating account");
          }
          res.send("User registered and signed in successfully!");
        });
      } catch (hashError) {
        console.error("Error hashing password:", hashError);
        res.status(500).send("Server error");
      }
    } else {
      // User found, check password
      const user = results[0];
      const passwordMatch = await bcrypt.compare(password, user.password);
      if (!passwordMatch) {
        res.status(401).send("Invalid credentials");
      } else {
        res.send("Sign-in successful!");
      }
    }
  });
});

router.get("/forgot-pass", (req, res) => {
  res.sendFile(path.join(__dirname, '../views', 'forgot-pass.html'));
});

// Forgot Password Route
router.post("/forgot-password", (req, res) => {
  const { email } = req.body;
  const sql = "SELECT * FROM users WHERE email = ?";
  db.query(sql, [email], (err, results) => {
    if (err) {
      console.error("Server error:", err);
      return res.status(500).send("Server error");
    }
    if (results.length === 0) return res.status(404).send("Email not found");

    res.send("Password reset link has been sent to your email.");
  });
});

module.exports = router;
